'use strict';

var webdriver = require('selenium-webdriver');


module.exports = function(driver){

}